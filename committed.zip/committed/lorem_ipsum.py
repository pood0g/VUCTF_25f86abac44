from lorem.text import TextLorem

gen = TextLorem()

print(gen.paragraph())